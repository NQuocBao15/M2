package views;

public enum Status {
    EDIT, ADD, REMOVE
}
